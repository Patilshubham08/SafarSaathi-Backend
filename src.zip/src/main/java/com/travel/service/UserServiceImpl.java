package com.travel.service;

public class UserServiceImpl implements UserService {

}
