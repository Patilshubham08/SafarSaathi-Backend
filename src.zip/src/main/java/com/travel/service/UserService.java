package com.travel.service;

public interface UserService {
      
}
