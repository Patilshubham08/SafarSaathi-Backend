package com.travel.entities;

public enum UserRole {
       Customer,Vendor
}
