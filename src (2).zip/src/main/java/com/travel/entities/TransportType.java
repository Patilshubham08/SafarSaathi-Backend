package com.travel.entities;

public enum TransportType {
	Flight, Train, Bus, Car, Other
}
