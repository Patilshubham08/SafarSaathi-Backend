package com.travel.entities;

public enum TripStatus {
	
	
	    SCHEDULED,
	    IN_PROGRESS,
	    COMPLETED,
	    CANCELLED, 
	   // PLANNED
	
}
